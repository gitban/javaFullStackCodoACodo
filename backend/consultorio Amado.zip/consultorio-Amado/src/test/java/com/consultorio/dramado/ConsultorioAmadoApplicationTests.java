package com.consultorio.dramado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsultorioAmadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
